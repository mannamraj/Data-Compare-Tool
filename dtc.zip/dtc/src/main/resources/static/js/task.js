(function() {

 formSave = function() {
                    alert("test");
    };

    var task = {

        loadData: function(filter) {
            return $.ajax({
                                url: "/dct/getTasks",
                                dataType: "json"
                              });
        },

        insertItem: function(insertingClient) {
            this.data.push(insertingClient);
        },

        updateItem: function(updatingClient) { },

        deleteItem: function(deletingClient) {
            var clientIndex = $.inArray(deletingClient, this.data);
            this.data.splice(clientIndex, 1);
        }

    };

    window.task = task;

 task.tasktypes = [
        { Name: "oracle", val: "oracle" },
        { Name: "mysql", val: "mysql" },
    ];

    task.countries = [
        { Name: "", Id: 0 },
        { Name: "United States", Id: 1 },
        { Name: "Canada", Id: 2 },
        { Name: "United Kingdom", Id: 3 },
        { Name: "France", Id: 4 },
        { Name: "Brazil", Id: 5 },
        { Name: "China", Id: 6 },
        { Name: "Russia", Id: 7 }
    ];

    task.data = [
       {}
     ];

}());
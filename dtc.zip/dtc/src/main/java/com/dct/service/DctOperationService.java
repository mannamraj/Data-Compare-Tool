package com.dct.service;

import com.dct.db.entity.DataSource;
import com.dct.db.entity.Task;

import java.util.List;

public interface DctOperationService {

    public DataSource save(DataSource dataSource);
    public List<DataSource> getDataSource();
    public Task save(Task task);
    public List<Task> getTasks();
    public List<String> getDataSources();
    public Task triggerTask(Task task);
    public DataSource getDataSourceByName(String dataSourceName);
}

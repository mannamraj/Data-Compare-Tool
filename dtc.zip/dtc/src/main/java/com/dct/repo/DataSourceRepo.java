package com.dct.repo;

import com.dct.db.entity.DataSource;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface DataSourceRepo extends CrudRepository<DataSource, Long> {

    @Query("select t.dbName from DataSource t")
    public List<String> getDataSources();

    public DataSource findDataSourceByDataSourceName(String dataSourceName);

}

package com.dct.impl;

import com.dct.db.db.DBUtil;
import com.dct.db.db.Pair;
import com.dct.db.db.TaskActionFactory;
import com.dct.db.db.TaskExectorDetails;
import com.dct.db.db.TaskResult;
import com.dct.db.entity.DataSource;
import com.dct.db.entity.Task;
import com.dct.repo.DataSourceRepo;
import com.dct.repo.TaskRepo;
import com.dct.service.DctOperationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class DctOperationServiceImpl implements DctOperationService {

    @Autowired
    private DataSourceRepo dataSourceRepo;

    @Autowired
    private TaskRepo taskRepo;

    @Override
    public DataSource save(DataSource dataSource) {

        return validate(dataSource) ? dataSourceRepo.save(dataSource):dataSource;
    }

    @Override
    public List<DataSource> getDataSource() {

        return (List<DataSource>) dataSourceRepo.findAll();
    }


    @Override
    public Task save(Task task) {
        return taskRepo.save(task);
    }

    @Override
    public List<Task> getTasks() {
        return (List<Task>) taskRepo.findAll();
    }

    @Override
    public List<String> getDataSources() {
        return dataSourceRepo.getDataSources();
    }

    @Override
    public Task triggerTask(Task task) {
        Task task1 = save(task);
        task1.setDataSource1(getDataSourceByName(task1.getDataSourceName1()));
        task1.setDataSource2(getDataSourceByName(task1.getDataSourceName2()));

        executeTask(task1);
        return task1;
    }

    @Override
    public DataSource getDataSourceByName(String dataSourceName) {
        return dataSourceRepo.findDataSourceByDataSourceName(dataSourceName);
    }

    public void executeTask(Task task){

        try {
            Thread thread = new Thread() {

                @Override
                public void run() {

                    try {
                        TaskResult<Map<Pair<String>, TaskExectorDetails>> taskExectorDetailsMap= TaskActionFactory.getAction(task.getTaskType())
                                .execute(task);

                        System.out.println(taskExectorDetailsMap);
                        task.setStatus("Completed");
                        taskRepo.save(task);
                        DBUtil.creatLog(task.getName(),taskExectorDetailsMap);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
            };
            thread.start();
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public boolean validate(DataSource dataSource){

        if(dataSourceRepo.findDataSourceByDataSourceName(dataSource.getDataSourceName()) != null ){
            dataSource.setValidatesStatus(false);
            dataSource.addError("Data Source Name Already Exist");
            return false;
        }

        return true;

    }
}

package com.dct.db.db;

public class TableTaskAction extends BaseExecutor  {

    @Override
    public Object execute() {
        return null;
    }
}

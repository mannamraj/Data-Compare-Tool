package com.dct.db.db;

import java.util.List;
import java.util.concurrent.Future;


public class TaskExectorDetails {

	public List<Future<Result>> futureList = null;

	String table;

	String tableTwo;

	StringBuffer dataDiff = new StringBuffer();

	boolean status = true;

	public List<Future<Result>> getFutureList() {
		return futureList;
	}

	public void setFutureList(List<Future<Result>> futureList) {
		this.futureList = futureList;
	}

	public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public StringBuffer getDataDiff() {
		return dataDiff;
	}

	public void setDataDiff(StringBuffer dataDiff) {
		this.dataDiff = dataDiff;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public String getTableTwo() {
		return tableTwo;
	}

	public void setTableTwo(String tableTwo) {
		this.tableTwo = tableTwo;
	}
}

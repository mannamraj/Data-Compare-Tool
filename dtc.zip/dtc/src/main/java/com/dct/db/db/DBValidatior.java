package com.dct.db.db;

import com.dct.db.entity.Task;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DBValidatior {

    public static boolean validateRecordCount(Pool pool, Task task, String table, StringBuffer zeroCount) throws SQLException {

        Integer countLeft = DBUtil.getCount(pool.getConnection(task.getDataSource1()),table);

        Integer countRight = DBUtil.getCount(pool.getConnection(task.getDataSource2()),table);

        if(countLeft == 0 && countRight == 0){
            zeroCount.append("false");
            return false;
        }

        return countLeft.equals(countRight);
    }

    public static boolean validateHeaderCount(Pool pool, Task task,String table1,String table2) throws SQLException {

        Integer countLeft = DBUtil.getHeaderCount(pool.getConnection(task.getDataSource1()),table1);

        Integer countRight = DBUtil.getHeaderCount(pool.getConnection(task.getDataSource2()),table2);

        return countLeft.equals(countRight);
    }


    public static boolean validateHeaderNames(Pool pool, Task task,String table1,String table2)  throws SQLException {

        boolean flag = true;
        ResultSetMetaData metaData1 = pool.getConnection(task.getDataSource1()).prepareStatement("select * from "+table1+" where 1 != 1").getMetaData();
        ResultSetMetaData metaData2 = pool.getConnection(task.getDataSource2()).prepareStatement("select * from "+table2+" where 1 != 1").getMetaData();

        int count  = metaData1.getColumnCount();
        List<String> list =  new ArrayList<String>();
        for(int i = 1;i <= count;i++ ){
            list.add(metaData1.getColumnName(i).toLowerCase());
        }

        for(int i = 1;i <= count;i++ ){

            if(!list.contains(metaData2.getColumnName(i).toLowerCase())){
                flag = false;
                break;
            }
        }
        return flag;
    }

    public static boolean validateTableCount(Object[] left,Pool pool, Task task) throws SQLException {

         Object[] right = DBUtil.getTable(task,2, pool.getConnection(task.getDataSource2()),(task.getDataSource2()));

        return getCount(left).equals(getCount(right));
    }

    public static Integer getCount(Object[] arr){

        int retVal = 0;
        if(arr != null){
            retVal = arr.length;
        }
        return retVal;
    }
}

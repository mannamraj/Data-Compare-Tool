package com.dct.db.db;

import java.util.ArrayList;
import java.util.List;

public class TaskResult<T> {

    private T result;

    private boolean status;

    private List<String> errorList =  new ArrayList<String>();

    public T getResult() {
        return result;
    }

    public void setResult(T result) {
        this.result = result;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public List<String> getErrorList() {
        return errorList;
    }

    public void setErrorList(List<String> errorList) {
        this.errorList = errorList;
    }
}

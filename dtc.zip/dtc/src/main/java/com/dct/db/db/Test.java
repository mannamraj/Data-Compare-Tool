package com.dct.db.db;

import com.dct.db.entity.DataSource;
import com.dct.db.entity.Task;

public class Test {


    public static void main(String args[]) throws Exception {

        Test1 test1 = null;

        // --- Test Data Preparation

        Class.forName("com.dct.db.db.Test1");

        System.out.println("test");
/*
        test1 = new Test1();

        test1 = new Test1();*/
/*


        DataSource dataSource =  getDataSource("source",
                "mysql",
                "",
                "localhost",
                "root",
                "mur",
                "",
                "",
                "3306",
                "offer");

        DataSource dataSource2 =  getDataSource("target",
                "mysql",
                "",
                "localhost",
                "root",
                "mur",
                "",
                "",
                "3306",
                "test");

        Task task1 = new Task();

        task1.setDataSource1(dataSource);

        task1.setDataSource2(dataSource2);

        task1.setDataSourceName1("source");

        task1.setDataSourceName2("source");

        task1.setTaskType("All");

        task1.setThreadCount(2);
        
        TaskActionFactory.getAction(task1.getTaskType()).execute(task1);

        //Thread.sleep(10000000000L);
*/

    }

   public static DataSource getDataSource(String dataSourceName,
                             String dbName,
                             String driverClass,
                             String host,
                             String user,
                             String password,
                             String sid,
                             String serviceName,
                             String port,
                             String dataBase){

        DataSource dataSource =  new DataSource();

        dataSource.setDataSourceName(dataSourceName);

        dataSource.setDataBase("");

        dataSource.setDbName(dbName);

        dataSource.setDriverClass(driverClass);

        dataSource.setHost(host);

        dataSource.setUserName(user);

        dataSource.setPassword(password);

        dataSource.setServiceName(serviceName);

        dataSource.setSid(sid);

        dataSource.setPort(port);
        
        dataSource.setDataBase(dataBase);

        return dataSource;
    }
}

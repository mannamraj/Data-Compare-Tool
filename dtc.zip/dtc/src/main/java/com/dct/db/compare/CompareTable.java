package com.dct.db.compare;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Properties;


public class CompareTable {
	
	Properties properties = new Properties();
	
	public Connection getConnection(String user,String password,String url,String driver){
		Connection con = null;
		try{
			
			Class.forName(driver);
			
			con = DriverManager.getConnection(url,user,password);
			
		}catch(Exception e){
			print(e.getMessage(),Thread.currentThread().getName()+"error");
			e.printStackTrace();
		}
		
		return con;	
	}
	
	void copareTable(){
		try{
			
		getPath();
						
		String user1 = properties.getProperty("user1");
		
		String password1 = properties.getProperty("password1");

		String url1 = properties.getProperty("url1");
		
		String user2 = properties.getProperty("user2");
		
		String password2 = properties.getProperty("password2");

		String url2 = properties.getProperty("url2");
		
		String driver = properties.getProperty("driver");
		

		Connection con1  = getConnection(user1, password1, url1, driver);
		
		Connection con2  = getConnection(user2, password2, url2,driver);
		
		String tables[] = properties.getProperty("tables").split(",");
		
		StringBuffer sf = new StringBuffer();
		
		for (String table : tables) {
			
			String orderBy = properties.getProperty(table+"-order") != null ? table+" order by "+properties.getProperty(table+"-order")+" asc"  :table+" order by rownum asc";
			
			PreparedStatement preparedStatement = con1.prepareStatement("select * from "+orderBy);
			
			PreparedStatement preparedStatement1 = con2.prepareStatement("select * from "+orderBy);
			
			ResultSet rs1 = preparedStatement.executeQuery();
			
			ResultSet rs2 = preparedStatement1.executeQuery();

			
			ResultSetMetaData rsmd = rs1.getMetaData();
			
		
			int colCount = rsmd.getColumnCount();
			
			String end = "\r\n";
			
			sf.append("Table:::"+table+end);
			
			boolean flag = false;
   
            while (rs1.next() && rs2.next()) {
           	
            	
	            for (int i = 1; i<=colCount; i++){
	                	
	             	   String colName = rsmd.getColumnName(i);
	             	   
	             	   if(!getVal(rs1.getString(colName)).equals(getVal(rs2.getString(colName)))){
	             		  flag = true;
	             		 sf.append(rs1.getString(colName)+" ##### "+rs1.getString(colName)+end);
	             		  break;
	             	   }
	             	  
	                    //String colType = rsmd.getColumnTypeName(i);
	            }
	            
	            if(flag){
	            	break;
	            }
	            
			}
            
            if(flag){
            	
            	sf.append("Table:::"+table+" not equal."+end);
            	
            }else{
            	
            	sf.append("Table:::"+table+" equal."+end);
            	
            }

           
          // sf.setLength(0);
			
		}
		
		 print(sf.toString(),"output");
		
		
		}catch(Exception e){
			print(e.getMessage(),"error");
			e.printStackTrace();
		}
		
	}
	
	private String getVal(String arg) {
		
		return arg != null ? arg : "";
	}

	void load(){
		try{
			/*InputStream is = CompareTable.class.getClassLoader()
			.getResourceAsStream("com/db/compare/config.properties");
			*/
			InputStream is = new FileInputStream(getPath()+"config.properties");
			properties.load(is);
			
		}catch(Exception e){
			print(e.getMessage(),"error1");
			e.printStackTrace();
		}
		
	}
	
	public void print(String data, String file){
		
	      try{    
	           FileWriter fw=new FileWriter(file+".txt");   
	           fw.write(data.toString());
	           fw.close();    
	          }catch(Exception e){
	        	  print(e.getMessage(),"error2");
	        	  System.out.println(e);
	          }
		
	}
	public static void main(String arg[]){
		CompareTable compareTable = new CompareTable();
		compareTable.load();
		compareTable.copareTable();
	}
	
private String getPath(){
		
		String cleanerBatchPath = CompareTable.class.getClassLoader().getResource("com/db/compare/config.properties").toString().replaceAll("file:/", "");
		
		cleanerBatchPath = cleanerBatchPath.replaceAll("jar:", "").replaceAll("%20", " ").split("DBCompare.jar")[0];
		
		print(cleanerBatchPath,"path");
		
		return cleanerBatchPath;
	}

}

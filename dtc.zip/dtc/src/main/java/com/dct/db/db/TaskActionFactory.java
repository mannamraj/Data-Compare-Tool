package com.dct.db.db;


public class TaskActionFactory {

    public static TaskAction getAction(String type){

        TaskAction taskAction = null;

        type = type.toLowerCase();

        switch (type){

            case  "all" :
            case "tables":

                taskAction = new TableExecutor2();

        }

        return taskAction;
    }
}


package com.dct.db.compare;

public interface TaskAction {

}

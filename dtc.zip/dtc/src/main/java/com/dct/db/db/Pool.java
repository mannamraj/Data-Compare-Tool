package com.dct.db.db;

import com.dct.db.entity.DataSource;
import com.dct.db.entity.Task;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class Pool {

    Random rand = new Random();

    private Map<String, List<Connection>> map = new HashMap<String, List<Connection>>();

    public void loadConnection(Task task){

        map.put(task.getDataSourceName1(),loadConnections(task.getDataSource1()));

        map.put(task.getDataSourceName2(),loadConnections(task.getDataSource2()));

    }

    private List<Connection> loadConnections(DataSource dataSource) {

        List<Connection> connections = new ArrayList<>();

        for (int i =0;i<DBCompareConstants.poolSize;i++) {

            connections.add(ConnectionUtil.getConnection(dataSource));

        }
        return connections;
    }

    public Connection getConnection(DataSource dataSource){

        return map.get(dataSource.getDataSourceName()).get(rand.nextInt(DBCompareConstants.poolSize));
    }

    public static Pool getInstance(Task task){
        Pool pool =new Pool();
        pool.loadConnection(task);
        return pool;
    }

    public void close() throws SQLException {

        for (Map.Entry<String,List<Connection>> entry : map.entrySet()) {

            for (Connection connection : entry.getValue()) {

                if(connection != null){
                    connection.close();
                }
            }
        }
    }
}

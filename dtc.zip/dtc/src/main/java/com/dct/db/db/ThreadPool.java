package com.dct.db.db;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ThreadPool {

    public static void main(String args[]) throws ExecutionException, InterruptedException {

        //ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(2);

        ExecutorService executor = Executors.newFixedThreadPool(2);


        TestCallBackExecutor testCallBackExecutor = new TestCallBackExecutor();

        Future<Object> framework = executor.submit(testCallBackExecutor);
/*
        System.out.println(((Employee)framework.get()).getName());

        framework.cancel(true);


        //executor.submit(t2);

        //System.out.println(this.wait(););

        executor.shutdown();*/
       /* while (!executor.isTerminated()) {
            // consider giving up with a 'break' statement under certain conditions
        }*/
        System.out.println("::::::::::: MAIN END ::::::::::::");

    }
}

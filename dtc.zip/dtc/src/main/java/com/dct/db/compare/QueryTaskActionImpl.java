package com.dct.db.compare;

public class QueryTaskActionImpl {

}

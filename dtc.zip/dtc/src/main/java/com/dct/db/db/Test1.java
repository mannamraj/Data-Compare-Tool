package com.dct.db.db;

public class Test1 {

    static {
        System.out.println("static block executed ");
    }
}

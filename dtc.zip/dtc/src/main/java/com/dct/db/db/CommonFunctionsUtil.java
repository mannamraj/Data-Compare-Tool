package com.dct.db.db;

public class CommonFunctionsUtil {


    public static int getAllocationLoopSize(int count, int chuckSize, int threadCount) {

        int allocationLoopSize = 1;

        if(count == threadCount){

            allocationLoopSize = threadCount;

        }else if(threadCount > count){

            allocationLoopSize = count ;

        }else if(count > threadCount){

            allocationLoopSize =  threadCount;
        }

        return allocationLoopSize;
    }

    public static int getChunkSize(int count, int threadCount) {

        int chunkSize = 1;

        if(count == threadCount){

            chunkSize = count / threadCount;

        }else if(threadCount > count){

            chunkSize = count /count;

        }else if(count > threadCount){

            chunkSize = count / threadCount;
        }
        System.out.println("chunkSize " +chunkSize);

        return chunkSize;
    }
}

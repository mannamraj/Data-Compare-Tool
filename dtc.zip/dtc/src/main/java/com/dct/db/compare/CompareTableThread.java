package com.dct.db.compare;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;


public class CompareTableThread {
	
	Properties properties = new Properties();
	
	public Connection getConnection(String user,String password,String url,String driver){
		Connection con = null;
		try{
			
			Class.forName(driver);
			
			con = DriverManager.getConnection(url,user,password);
			
		}catch(Exception e){
			print(e.getMessage(),"error");
			e.printStackTrace();
		}
		
		return con;	
	}
	
	void copareTable(){
		try{
			
			String endLine = "\r\n";
			
		//getPath();
			
		List<Future<StringBuffer>> listfFutures = new ArrayList<Future<StringBuffer>>();
			
		Integer size = Integer.parseInt(properties.getProperty("thread"));
		
		ExecutorService es=Executors.newFixedThreadPool(size);
						
		String user1 = properties.getProperty("user1");
		
		String password1 = properties.getProperty("password1");

		String url1 = properties.getProperty("url1");
		
		String user2 = properties.getProperty("user2");
		
		String password2 = properties.getProperty("password2");

		String url2 = properties.getProperty("url2");
		
		String driver = properties.getProperty("driver");
		

		Connection con1  = getConnection(user1, password1, url1, driver);
		
		Connection con2  = getConnection(user2, password2, url2,driver);
		
		String tables[] = properties.getProperty("tables").split(",");
		
		StringBuffer sf = new StringBuffer();
		
		for (String table : tables) {
			
			listfFutures.clear();
			
			int count  = getCount(table,con1);
			
			int chuckSize = count/size;
			
			int start = 0;
			
			int end = chuckSize;
			
			
			for (int i = 1; i <= size; i++) {
				
				if(i !=1){
					start = end ;
				}
				end =   i * chuckSize;
				
				if(i == size && end < count){
					
					end  = end + (count - end);
					
				}			
				
				String orderBy = properties.getProperty(table+"-order") != null ? " order by "+properties.getProperty(table+"-order")+" asc"  :" order by rownum asc";
				
				String page = driver.contains("oracle")? "WHERE ROWNUM > "+start+" and ROWNUM < "+end:" LIMIT "+start+" , "+end;
				
				String query = driver.contains("oracle") ? "select * from "+table+" " +page+" "+orderBy : "select * from "+table+" " +orderBy+" "+page ;
					
				CompareTask compareTask = new CompareTask(start, end, con1, con2, query, table);
				
				listfFutures.add(es.submit(compareTask));
				
			}
			
			//StringBuffer temBuffer = new StringBuffer();
			
			StringBuffer resultNEQ = new StringBuffer();

			boolean notEQFlag = false;
			
			for(Future<StringBuffer> future : listfFutures){
				
				//temBuffer.append(future.get());
				
				if(future.get().toString().contains("not equal")){
					
					resultNEQ.append(future.get());
					
					notEQFlag = true;
					
					break;
				}
				
			}
			
			if(notEQFlag){
				
				sf.append("Table:::"+table+" not equal."+endLine);
				
				sf.append(resultNEQ.toString()+endLine);
				
				break;
				
			}else{
				
				sf.append("Table:::"+table+" equal."+endLine);
				
			}
			
						
		}
		
		 print(sf.toString(),"output");
		
		 es.shutdown();
		 
		}catch(Exception e){
			print(e.getMessage(),"error");
			e.printStackTrace();
		}
		
		
		
	}
	
	private String getVal(String arg) {
		
		return arg != null ? arg : "";
	}

	void load(){
		try{
			/*InputStream is = CompareTable.class.getClassLoader()
			.getResourceAsStream("com/db/compare/config.properties");*/
			
			InputStream is = new FileInputStream(getPath()+"config.properties");
			properties.load(is);
			
		}catch(Exception e){
			print(e.getMessage(),"error1");
			e.printStackTrace();
		}
		
	}
	
	public void print(String data, String file){
		
	      try{    
	           FileWriter fw=new FileWriter(file+".txt");   
	           fw.write(data.toString());
	           fw.close();    
	          }catch(Exception e){
	        	  print(e.getMessage(),"error2");
	        	  System.out.println(e);
	          }
		
	}
	public static void main(String arg[]){
		CompareTableThread compareTable = new CompareTableThread();
		compareTable.load();
		compareTable.copareTable();
	}
	
private String getPath(){
		
		String cleanerBatchPath = CompareTableThread.class.getClassLoader().getResource("com/db/compare/config.properties").toString().replaceAll("file:/", "");
		
		cleanerBatchPath = cleanerBatchPath.replaceAll("jar:", "").replaceAll("%20", " ").split("DBCompare.jar")[0];
		
		print(cleanerBatchPath,"path");
		
		return cleanerBatchPath;
}

	public int getCount(String table, Connection con1) throws SQLException{
		
		PreparedStatement ps = con1.prepareStatement("select count(*) AS rowcount from "+table);
		
		ResultSet rs = ps.executeQuery();
		rs.next();
		//print(rs.getString("rowcount"), "count");
		return rs.getInt("rowcount");
		
	}
	
	/*public int getChunck(int count){
		
	switch(count){
		case 100:
			
			return -1;
			
		case 1000:
			
			return 2;
			
		case 10000:
			
			10;
			
			
	}
		return 0;
		
	}*/
}

package com.dct.db.db;

import com.dct.db.entity.DataSource;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class DBCompareTask extends  BaseExecutor {


    DataSource source;

    CompareData compareData = null;
    
    TaskActionData taskActionData = null;

    public DBCompareTask(TaskActionData taskActionData){
    	this.taskActionData = taskActionData;
    }
  /*  public DBCompareTask(String queryOne,
    		String queryTwo,
                         Connection connection1,
                         Connection connection2){

        this.queryOne = queryOne;
        this.queryTwo = queryTwo;
        this.connection1 = connection1;
        this.connection2 = connection2;

    }*/

    @Override
    public Object execute() {

        PreparedStatement preparedStatement1 = null;
        PreparedStatement preparedStatement2 = null;
        ResultSet resultSet1 = null;
        ResultSet resultSet2 = null;

        try{

            preparedStatement1 = taskActionData.getConnectionOne().prepareStatement(taskActionData.getQueryOne());

            preparedStatement2 = taskActionData.getConnectionTwo().prepareStatement(taskActionData.getQueryTwo());

            resultSet1 = preparedStatement1.executeQuery();

            resultSet2 = preparedStatement2.executeQuery();

            ResultSetMetaData resultSetMetaData = preparedStatement1.getMetaData();

            CompareData compareData = new CompareData(resultSet1,resultSet2,resultSetMetaData);

            return DBUtil.compare(compareData);

        }catch (Exception e){
        	e.printStackTrace();
        }
        finally {
            try {
                if(resultSet1!=null) resultSet1.close(); //close resultSet
                if(resultSet2!=null) resultSet2.close(); //close resultSet
                if(preparedStatement1!=null) preparedStatement1.close(); //close PreparedStatement
                if(preparedStatement2!=null) preparedStatement2.close(); //close PreparedStatement

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return null;
    }
}

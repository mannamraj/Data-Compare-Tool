package com.dct.db.db;

public class Pair<T> {

	T one;
	T two;
	
	public T getOne() {
		return one;
	}
	public void setOne(T one) {
		this.one = one;
	}
	public T getTwo() {
		return two;
	}
	public void setTwo(T two) {
		this.two = two;
	}
	
	
}

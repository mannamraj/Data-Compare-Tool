package com.dct.db.db;

public class QueryTaskAction {
}

package com.dct.db.entity;

import javax.persistence.Transient;
import java.util.ArrayList;
import java.util.List;

public class BaseDataSource {

    @Transient
    private boolean validatesStatus = true;

    @Transient
    private List<String> list =  new ArrayList<String>();

    public List<String> getList() {
        return list;
    }

    public void setList(List<String> list) {
        this.list = list;
    }

    public void addError(String msg) {
        this.list.add(msg);
    }

    public boolean isValidatesStatus() {
        return validatesStatus;
    }

    public void setValidatesStatus(boolean validatesStatus) {
        this.validatesStatus = validatesStatus;
    }
}

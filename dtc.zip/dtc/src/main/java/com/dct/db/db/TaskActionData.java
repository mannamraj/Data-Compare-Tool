package com.dct.db.db;

import com.dct.db.entity.DataSource;

import java.sql.Connection;

public class TaskActionData {

    private Connection connectionOne;

    private Connection connectionTwo;

    private String queryOne;

    private String queryTwo;

    private String table;

    DataSource dataSource1;

    DataSource getDataSource2;
    
    
    public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public Connection getConnectionOne() {
        return connectionOne;
    }

    public void setConnectionOne(Connection connectionOne) {
        this.connectionOne = connectionOne;
    }

    public Connection getConnectionTwo() {
        return connectionTwo;
    }

    public void setConnectionTwo(Connection connectionTwo) {
        this.connectionTwo = connectionTwo;
    }

    public String getQueryOne() {
        return queryOne;
    }

    public void setQueryOne(String queryOne) {
        this.queryOne = queryOne;
    }

    public String getQueryTwo() {
        return queryTwo;
    }

    public void setQueryTwo(String queryTwo) {
        this.queryTwo = queryTwo;
    }

    public DataSource getDataSource1() {
        return dataSource1;
    }

    public void setDataSource1(DataSource dataSource1) {
        this.dataSource1 = dataSource1;
    }

    public DataSource getGetDataSource2() {
        return getDataSource2;
    }

    public void setGetDataSource2(DataSource getDataSource2) {
        this.getDataSource2 = getDataSource2;
    }
}

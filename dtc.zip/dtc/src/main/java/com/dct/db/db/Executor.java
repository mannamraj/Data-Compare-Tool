package com.dct.db.db;

import com.dct.db.entity.Task;

public interface Executor {
	
	 public Object execute(Task task);

}

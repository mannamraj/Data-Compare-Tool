package com.dct.db.db;


import com.dct.db.entity.DataSource;
import com.dct.db.entity.Task;

import java.io.FileWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.Map;

public class DBUtil {
	
    static Object compare(CompareData compareData)throws SQLException{

        StringBuffer result = new StringBuffer();

        Result returnResult = new Result();

        ResultSet rs1= compareData.getResultSet1();

        ResultSet rs2= compareData.getResultSet2();

        ResultSetMetaData resultSetMetaData = compareData.getResultSetMetaData();

        int size = resultSetMetaData.getColumnCount();

        compareData.setSize(size);

        returnResult.setStatus(true);


        //if(!(rs1.getFetchSize() == rs2.getFetchSize())){

            while (rs1.next() && rs2.next()){

                if(!compareRow(compareData)){

                    result.append(DBCompareConstants.end+getData(compareData));
                   
                    returnResult.setStatus(false);

                   // break;
                }
           }

        /*}else{

            result = "Table Count Not Equal";
        }*/

        returnResult.setResult(result.toString());

        returnResult.setTable(resultSetMetaData.getTableName(1));

        return returnResult;
    }

    private static boolean compareRow(CompareData compareData) throws SQLException {

        boolean result = true;
        for (int i=1;i<=compareData.getSize();i++){

            try {
                if (!getVal(compareData.getResultSet1().getString(compareData.getResultSetMetaData().getColumnName(i))).equals(
                        getVal(compareData.getResultSet2().getString(compareData.getResultSetMetaData().getColumnName(i))))) {
                    result = false;
                    break;
                }
            }catch (Exception e){
                System.out.println("Table Name  : "+compareData.getResultSetMetaData().getTableName(i));
                System.out.println("Column Name :"+compareData.getResultSetMetaData().getColumnName(i));
                System.out.println("Column Type  : "+compareData.getResultSetMetaData().getColumnTypeName(i));
                e.printStackTrace();
            }
        }

        return result;
    }
    
    public static String getVal(String arg){
    	
    		return arg != null ? arg : "";
    	
    }

    private static String getData(CompareData compareData) throws SQLException {

        StringBuffer rowData1 = new StringBuffer();

        StringBuffer rowData2 = new StringBuffer();

        StringBuffer diffData = new StringBuffer();

        for (int i=1;i<=compareData.getSize();i++){

            try {

                String column = compareData.getResultSetMetaData().getColumnName(i);

                String data1 = compareData.getResultSet1().getString(column);

                String data2 = compareData.getResultSet2().getString(column);

                if(!getVal(data1).equals(getVal(data2))){

                    diffData.append(DBCompareConstants.end+"Column Name : "+column+" - Data Differenc  :::: "+data1+" ::: "+data2);

                    rowData1.append(" "+data1);
                    rowData2.append(" "+data2);
                }
            }catch (Exception e){
                System.out.println("Table Name  : "+compareData.getResultSetMetaData().getTableName(i));
                System.out.println("Column Name :"+compareData.getResultSetMetaData().getColumnName(i));
                System.out.println("Column Type  : "+compareData.getResultSetMetaData().getColumnTypeName(i));
                e.printStackTrace();
            }

        }

        return  diffData.toString()+"\r\n"+rowData1.toString()+"\r\n"+rowData2.toString();
    }

    public static Object[] getAllTables(DataSource dataSource,Connection connection) throws SQLException {

        ArrayList list = new ArrayList();

        //DatabaseMetaData md = connection.getMetaData();

        String query = null;
        if("oracle".equalsIgnoreCase(dataSource.getDbName())){
            query = "select tname from tab";
        }
        if(("mysql".equalsIgnoreCase(dataSource.getDbName()))){
            query = "show tables";
        }


        ResultSet rs = connection.prepareStatement(query).executeQuery();

        while (rs.next()) {

           // System.out.println(rs.getString(1) + "###"+rs.getString(3));
                /*
                if("mysql".equalsIgnoreCase(dataSource.getDbName()) &&dataSource.getDataBase()
                        .equalsIgnoreCase(rs.getString(1))) {
                    list.add(rs.getString(3));
                }else if("oracle".equalsIgnoreCase(dataSource.getDbName())){

                    list.add(rs.getString(3));

                }*/

            list.add(rs.getString(1));

        }

        return  list.toArray();
    }
    
    static public Connection getConnection(String dataSourc){
    	
    	return ConnectionUtil.getConnection(null);
    }

    static public Connection getConnection(DataSource dataSourc){
    	
    	return ConnectionUtil.getConnection(null);
    }

   Pair<Connection> getConnectionPair(Task task){
	   
	   Pair<Connection> pair = new Pair<Connection>();
	      
	   return pair;
	   
   }
   
   public static Integer getCount(Connection connection, String table) throws SQLException{
	   
	   ResultSet rs = connection.prepareStatement("select count(*) from "+table).executeQuery();

	   rs.next();

	   return rs.getInt(1);
	  }

    public static Integer getHeaderCount(Connection connection, String table) throws SQLException{

        return connection.prepareStatement("select * from "+table+" where 1 != 1").getMetaData().getColumnCount();
    }

    public static void print(String data, String file){

        try{
            FileWriter fw=new FileWriter(file+".txt");
            fw.write(data.toString());
            fw.close();
        }catch(Exception e){
            print(e.getMessage(),"error2");
            System.out.println(e);
        }

    }

    public  static void creatLog(String task,TaskResult<Map<Pair<String>, TaskExectorDetails>> taskResult){

        StringBuffer sb = new StringBuffer();

        String end = DBCompareConstants.end;

        Map<Pair<String>, TaskExectorDetails> taskExectorDetailsMap = taskResult.getResult();

        if(taskResult.isStatus()){

            for (Map.Entry<Pair<String>, TaskExectorDetails> entry : taskExectorDetailsMap.entrySet()) {

                TaskExectorDetails taskExectorDetails = entry.getValue();

                sb.append("\nTable :"+entry.getKey().one+"  "+entry.getKey().one+ end);

                if(!taskExectorDetails.isStatus()){

                    sb.append("Result : Not Equal"+end);

                    sb.append("Data Diff : "+taskExectorDetails.getDataDiff()+end);

                }else{

                    sb.append("Result : Table  Equal  "+ end);
                }
            }
        }else{
            for (String result:taskResult.getErrorList()) {
                sb.append(result);
            }
        }

        print(sb.toString(),task);

    }



    private String getPath(){

        String cleanerBatchPath = DBUtil.class.getClassLoader().getResource("com/db/compare/config.properties").toString().replaceAll("file:/", "");

        cleanerBatchPath = cleanerBatchPath.replaceAll("jar:", "").replaceAll("%20", " ").split("DBCompare.jar")[0];

        print(cleanerBatchPath,"path");

        return cleanerBatchPath;
    }

    public static int getChunkSize(Integer totalRecords){

        /*if(){

        }*/
        return 0;
    }

    public static Object[] getTable(Task task, int from, Connection connection,DataSource dataSource) throws SQLException {

        Object[] tableArray = null;


            if("all".equalsIgnoreCase(task.getTaskType())){

                tableArray = getAllTables(dataSource,connection);

            }else if(from == 1){

                tableArray = task.getTableList1().split(",");
            }else if(from == 2){

                tableArray = task.getTableList2().split(",");
            }



        return tableArray;
    }

    public static String getPrimaryKeyColumn(String table,Connection connection,String dataBase) throws SQLException {

        String pkColumn = "";
        DatabaseMetaData meta = connection.getMetaData();

        ResultSet rs = meta.getPrimaryKeys(null, null, table);

        while (rs.next()) {
            pkColumn = rs.getString("COLUMN_NAME");
            System.out.println("getPrimaryKeys(): columnName=" + pkColumn);
            break;
        }

        switch (dataBase.toLowerCase()) {
            case "oracle":
                pkColumn = "rownum";
                break;
        }

        return pkColumn;
    }

}

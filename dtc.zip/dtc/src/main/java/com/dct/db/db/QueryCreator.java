package com.dct.db.db;

import com.dct.db.entity.DataSource;
import org.springframework.util.StringUtils;

public class QueryCreator {


	public static String getQuery(String driver){
		
		String querString = null;
		switch (driver) {
		case "oracle":
			
			querString = "SELECT * " +
	                "  FROM (SELECT A.*, rownum rn" +
	                "          FROM (SELECT *" +
	                "                  FROM :tablePlace " +
	                "              	:orderBy ) A" +
	                "         WHERE rownum <= :pageEnd)" +
	                " WHERE rn >= :pageStart";
			break;
			
		case "mysql":
			
			querString = "SELECT * " +
	                "  FROM :tablePlace :orderBy" +
	                " LIMIT :pageStart , :pageEnd";
			
			break;
		}
		
		return querString;
		
	}
	
	public static String prepareQuery(String query, DataSource dataSource1, String table, Integer start, Integer end,String pkColumn) {

		String result = null;

		switch (dataSource1.getDbName().toLowerCase()) {

			case "oracle":

				Integer pageStart = start;
				if(start !=0){
					pageStart = start + 1 ;
				}

				result = query.replace(":tablePlace",table).replace(":pageStart", pageStart.toString()).replace(":pageEnd", end.toString())
				.replace(":orderBy"," order by "+pkColumn);

				break;

			case "mysql":

				//start = start +1;

				Integer pageEnd = end - start;

				result = query.replace(":tablePlace",table).replace(":pageStart", start.toString()).replace(":pageEnd", pageEnd.toString());

				if(!StringUtils.isEmpty(pkColumn)){
					result = result.replace(":orderBy"," order by "+pkColumn);
				}else{
					result = result.replace(":orderBy","");
				}

				break;
		}


		return result;
    }
}

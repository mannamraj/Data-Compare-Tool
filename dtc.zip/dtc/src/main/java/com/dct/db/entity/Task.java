package com.dct.db.entity;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

@Entity
public class Task extends BaseDataSource {

    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Long id;
    private String name;
    private String dataSourceName1;
    private String dataSourceName2;
    private String status;
    private String taskType;
    private String tables;
    private String firstQuery;
    private String secondQuery;
    private Integer threadCount;
    private String tableList1;
    private String tableList2;
    @Transient
    private DataSource dataSource1;
    @Transient
    private DataSource dataSource2;

    public String getDataSourceName1() {
        return dataSourceName1;
    }

    public void setDataSourceName1(String dataSourceName1) {
        this.dataSourceName1 = dataSourceName1;
    }

    public String getDataSourceName2() {
        return dataSourceName2;
    }

    public void setDataSourceName2(String dataSourceName2) {
        this.dataSourceName2 = dataSourceName2;
    }

    public DataSource getDataSource1() {
        return dataSource1;
    }

    public void setDataSource1(DataSource dataSource1) {
        this.dataSource1 = dataSource1;
    }

    public DataSource getDataSource2() {
        return dataSource2;
    }

    public void setDataSource2(DataSource dataSource2) {
        this.dataSource2 = dataSource2;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType;
    }

    public String getTables() {
        return tables;
    }

    public void setTables(String tables) {
        this.tables = tables;
    }

    public String getFirstQuery() {
        return firstQuery;
    }

    public void setFirstQuery(String firstQuery) {
        this.firstQuery = firstQuery;
    }

    public String getSecondQuery() {
        return secondQuery;
    }

    public void setSecondQuery(String secondQuery) {
        this.secondQuery = secondQuery;
    }

    public Integer getThreadCount() {
        return threadCount;
    }

    public void setThreadCount(Integer threadCount) {
        this.threadCount = threadCount;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }


    public String getTableList1() {
        return tableList1;
    }

    public void setTableList1(String tableList1) {
        this.tableList1 = tableList1;
    }

    public String getTableList2() {
        return tableList2;
    }

    public void setTableList2(String tableList2) {
        this.tableList2 = tableList2;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}

package com.dct.db.compare;

import java.util.concurrent.ExecutorService;

public class TriggerTask {
	
	public static void main(String args[]){
		
		
		ExecutorService executorService = null;
		
		
	}

}

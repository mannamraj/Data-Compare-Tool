package com.dct.db.db;


public class ExecutorFactory {
	
	
	
/*	public Executor getExecutor(Task task){
		
		switch (task.getTaskType()) {
		case "table":
			
			
			break;

		default:
			break;
		}
	}*/

}

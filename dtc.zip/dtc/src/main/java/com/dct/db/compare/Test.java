package com.dct.db.compare;

public class Test {

	public static void main(String agrs[]){
		
		int count = 7;
		
		int threadCount = 2;
		
		int chuckSize = getChunkSize(count,threadCount);//count/threadCount;
		
		int start = 0;
		
		int end = chuckSize;

		int allocationLoopSize = getAllocationLoopSize(count,chuckSize,threadCount);
		
		for (int i = 1; i <= allocationLoopSize; i++) {
			
			if(i !=1){
				start = end ;
			}
			end =   i * chuckSize;
			
			if(i == allocationLoopSize && end < count){
				
				end  = end + (count - end);
				
			}

			System.out.println(start+" === "+ (end));
			System.out.println(start+" === "+ (end - start));
			
		}
	}

	private static int getAllocationLoopSize(int count, int chuckSize, int threadCount) {

		int allocationLoopSize = 1;

		if(count == threadCount){

			allocationLoopSize = threadCount;

		}else if(threadCount > count){

			allocationLoopSize = count ;

		}else if(count > threadCount){

			allocationLoopSize =  threadCount;
		}

		return allocationLoopSize;
	}

	private static int getChunkSize(int count, int threadCount) {

		int chunkSize = 1;

		if(count == threadCount){

			chunkSize = count / threadCount;

		}else if(threadCount > count){

			chunkSize = count /count;

		}else if(count > threadCount){

			chunkSize = count / threadCount;
		}

		System.out.println("chunkSize " +chunkSize);

		return chunkSize;
	}
}

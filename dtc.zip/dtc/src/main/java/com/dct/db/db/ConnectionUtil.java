package com.dct.db.db;



import com.dct.db.entity.DataSource;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionUtil {

    public static Connection getConnection(DataSource dataSource){

        Connection connection = null;

        try{
        	updateDBDetails(dataSource);
        	
            Class.forName(dataSource.getDriverClass());

            connection = DriverManager.getConnection(dataSource.getConnectionURL(),
                    dataSource.getUserName(),
                    dataSource.getPassword());

        }catch (Exception e){

        	e.printStackTrace();
        }

        return connection;

    }
    
    public static void updateDBDetails(DataSource dataSource){
    	
    	String driverClass = null;
    	
    	String url = null;
    	
    	switch (dataSource.getDbName().toLowerCase()) {
    	
		case "oracle":
			
			driverClass = "oracle.jdbc.driver.OracleDriver";
			
			dataSource.setDriverClass(driverClass);
			
			 url = "jdbc:oracle:thin:@[HOST]:[PORT]:SID"
					.replace("[HOST]", dataSource.getHost())
					.replace("[PORT]", dataSource.getPort())
					.replace("SID",dataSource.getSid());
			
			dataSource.setConnectionURL(url);
			
			break;
			
		case "mysql":
			
			driverClass = "com.mysql.jdbc.Driver";
			
			dataSource.setDriverClass(driverClass);
			
			url = "jdbc:mysql://[HOST]:[PORT]/[DBNAME]?zeroDateTimeBehavior=convertToNull&useUnicode=true&characterEncoding=UTF-8"
					.replace("[HOST]", dataSource.getHost())
					.replace("[PORT]", dataSource.getPort())
					.replace("[DBNAME]",dataSource.getDataBase());
			 
			dataSource.setConnectionURL(url);

			break;

		default:
			break;
		}
    	
    }
}

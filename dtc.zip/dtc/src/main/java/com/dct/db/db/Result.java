package com.dct.db.db;

public class Result {

    private String result;

    private boolean status;
    
    private String table;
    

    public String getTable() {
		return table;
	}

	public void setTable(String table) {
		this.table = table;
	}

	public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}

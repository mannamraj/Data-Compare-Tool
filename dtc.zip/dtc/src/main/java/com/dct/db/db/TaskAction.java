package com.dct.db.db;

import com.dct.db.entity.Task;

import java.util.Map;
import java.util.concurrent.ExecutionException;

public interface TaskAction {

    public TaskResult<Map<Pair<String>,TaskExectorDetails>> execute(Task task) throws ExecutionException, Exception;
}

package com.dct.db.db;

import java.util.concurrent.Callable;

public abstract class BaseExecutor extends DBUtil implements Callable {
    @Override
    public Object call() throws Exception {

        //System.out.println("Start :::: END");

        return  execute();

    }

    public abstract Object execute();
}

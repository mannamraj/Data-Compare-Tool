package com.dct.db.db;

import com.dct.db.entity.Task;
import com.dct.repo.TaskRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class TableExecutor implements TaskAction {

    @Autowired
    TaskRepo taskRepo;

    public TaskResult<Map<Pair<String>,TaskExectorDetails>> execute(Task task) throws Exception{

        long startTime = System.currentTimeMillis();

        TaskResult<Map<Pair<String>,TaskExectorDetails>> taskResult = new TaskResult<Map<Pair<String>,TaskExectorDetails>>();

        Integer threadCount = task.getThreadCount();

        ExecutorService executor = Executors.newFixedThreadPool(threadCount);

        Pool pool = Pool.getInstance(task);

        List<Future<Result>> listFutures = null;

        int start = 0;

        int end = 0;

        Object[] tables  = DBUtil.getTable(task,1,pool.getConnection(task.getDataSource1()),task.getDataSource1());

        if(!DBValidatior.validateTableCount(tables,pool,task)){
            pool.close();
            taskResult.setStatus(false);
            taskResult.getErrorList().add("Both The Data Sources Having Different Table Count");
            return taskResult;
        }

        Object[] secondDataSourceTables  = "all".equalsIgnoreCase(task.getTaskType()) ? tables :
                DBUtil.getTable(task,2, pool.getConnection(task.getDataSource1()),task.getDataSource1());

        Map<Pair<String>,TaskExectorDetails> tasMap = new HashMap<Pair<String>, TaskExectorDetails>();


        for (int j = 0 ; j < tables.length ; j++) {

        	String table = tables[j].toString();

            Pair<String> pair =  new Pair<String>();

            pair.setOne(table);

            pair.setTwo(secondDataSourceTables[j].toString());


            TaskExectorDetails taskExectorDetails = new TaskExectorDetails();

            if (validate(task, pool, tasMap,pair, taskExectorDetails)){
                continue;
            }

            Pair<String> pkColumn = new Pair<>();
            pkColumn.one = DBUtil.getPrimaryKeyColumn(pair.one,pool.getConnection(task.getDataSource1()),task.getDataSource1().getDbName());
            pkColumn.two = DBUtil.getPrimaryKeyColumn(pair.two,pool.getConnection(task.getDataSource2()),task.getDataSource2().getDbName());
            int totalRecords = getCount(pool.getConnection(task.getDataSource1()),table);

        	int chuckSize = CommonFunctionsUtil.getChunkSize(totalRecords,threadCount);

            int allocationLoopSize = CommonFunctionsUtil.getAllocationLoopSize(totalRecords,chuckSize,threadCount);
        	
    		start = 0;
    		
    		end = chuckSize;
    		
    		listFutures = new ArrayList<Future<Result>>(allocationLoopSize);
    		
    		taskExectorDetails.setFutureList(listFutures);

    		tasMap.put(pair, taskExectorDetails);
        	
            for (int i = 1; i <= allocationLoopSize; i++) {
            	
            	TaskActionData taskActionData = new TaskActionData();
                
                taskActionData.setConnectionOne(pool.getConnection(task.getDataSource1()));
                  
                taskActionData.setConnectionTwo(pool.getConnection(task.getDataSource2()));

                taskActionData.setDataSource1(task.getDataSource1());

                taskActionData.setDataSource1(task.getDataSource2());

                taskActionData.setTable(table);
                
                if(i !=1){
    				start = end ;
    			}
    			end =   i * chuckSize;
    			
    			if(i == allocationLoopSize && end < totalRecords){
    				
    				end  = end + (totalRecords - end);
    				
    			}

                taskActionData.setQueryOne(QueryCreator.prepareQuery(QueryCreator.getQuery(task.getDataSource1().getDbName()),task.getDataSource1(),table, start, end,pkColumn.one));

                taskActionData.setQueryTwo(QueryCreator.prepareQuery(QueryCreator.getQuery(task.getDataSource2().getDbName()), task.getDataSource2(),secondDataSourceTables[j].toString(), start, end,pkColumn.two));
                
                System.out.println(taskActionData.getQueryOne());
                
                System.out.println(taskActionData.getQueryTwo());
                
                DBCompareTask dbCompareTask = new DBCompareTask(taskActionData);

                Future<Result> future = executor.submit(dbCompareTask);

                listFutures.add(future);
            }
        }

        executor.shutdown();
        
        for (Map.Entry<Pair<String>, TaskExectorDetails> entry : tasMap.entrySet()) {

            if(!CollectionUtils.isEmpty(entry.getValue().getFutureList())){

                List<Future<Result>> list = entry.getValue().getFutureList();

                TaskExectorDetails taskExectorDetails = entry.getValue();

                taskExectorDetails.setTable(entry.getKey().one);

                taskExectorDetails.setTableTwo(entry.getKey().two);

                for (Future<Result> object:list) {

                    Result result = object.get();

                    if(result != null){

                        if(!result.isStatus()){

                            taskExectorDetails.getDataDiff().append(result.getResult());

                            taskExectorDetails.setStatus(false);

                        }

                    }

                }
            }


		}

        pool.close();

        System.out.println("Start : "+startTime);
        System.out.println("End : "+System.currentTimeMillis());
        System.out.println("Time Diff " +(System.currentTimeMillis() - startTime));

        taskResult.setStatus(true);
        taskResult.setResult(tasMap);

        return taskResult;
       
    }

    private boolean validate(Task task, Pool pool, Map<Pair<String>, TaskExectorDetails> tasMap, Pair<String> pair, TaskExectorDetails taskExectorDetails) throws SQLException {

        StringBuffer zeroCount =  new StringBuffer();

        if(!DBValidatior.validateRecordCount(pool,task,pair.one,zeroCount)){

            if("false".equalsIgnoreCase(zeroCount.toString())){
                taskExectorDetails.setStatus(true);
                //taskExectorDetails.getDataDiff().append(pair.one +" table record count mismatch with table "+pair.two);

            }else{
                taskExectorDetails.setStatus(false);
                taskExectorDetails.getDataDiff().append(pair.one +" table record count mismatch with table "+pair.two);

            }
            tasMap.put(pair,taskExectorDetails);

            return true;
        }

        if(!DBValidatior.validateHeaderCount(pool,task,pair.one,pair.two)){

            taskExectorDetails.setStatus(false);
            taskExectorDetails.getDataDiff().append(pair.one +" table column count mismatch with table "+pair.two);
            tasMap.put(pair,taskExectorDetails);

            return true;
        }
        if(!DBValidatior.validateHeaderNames(pool,task,pair.one,pair.two)){

            taskExectorDetails.setStatus(false);
            taskExectorDetails.getDataDiff().append(pair.one +" table column names mismatch with table "+pair.two);
            tasMap.put(pair,taskExectorDetails);

            return true;
        }
        return false;
    }


    public TableExecutor setTaskRepo(TaskRepo taskRepo){
        this.taskRepo = taskRepo;

        return this;
    }



    private int getCount(Connection connection, String table) throws SQLException {

        return DBUtil.getCount(connection,table);
    }

}
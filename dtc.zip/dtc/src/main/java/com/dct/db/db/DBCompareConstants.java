package com.dct.db.db;

public class DBCompareConstants {

    public static Integer poolSize = 3;

    public static  String end ="\r\n";
}

package com.dct.db.compare;

import java.io.FileWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.concurrent.Callable;

public class CompareTask  implements Callable<StringBuffer>{
	
	private Integer start ;
	
	private Integer end;
	
	private Connection con1;
	
	private Connection con2;
	
	private String query;
	
	private String table;


	
	public CompareTask(Integer start,Integer end,
			Connection con1,Connection con2,String query,String table){
		
		this.start = start;
		this.end = end;
		this.con1 = con1;
		this.con2 = con2;
		this.query = query;
		this.table = table;
	}

	@Override
	public StringBuffer call() throws Exception {
		
		StringBuffer sf = new StringBuffer();
		
		try{
		
			//print(query,Thread.currentThread().getName());
			
			PreparedStatement preparedStatement = con1.prepareStatement(query);
			
			PreparedStatement preparedStatement1 = con2.prepareStatement(query);
			
			ResultSet rs1 = preparedStatement.executeQuery();
			
			ResultSet rs2 = preparedStatement1.executeQuery();
	
			
			ResultSetMetaData rsmd = rs1.getMetaData();
			
		
			int colCount = rsmd.getColumnCount();
			
			String endLine = "\r\n";
			
			sf.append("Table:::"+table+endLine);
			
			boolean flag = false;
	
	        while (rs1.next() && rs2.next()) {
	        	
	        	
	            for (int i = 1; i<=colCount; i++){
	                	
	             	   String colName = rsmd.getColumnName(i);
	             	   
	             	   if(!getVal(rs1.getString(colName)).equals(getVal(rs2.getString(colName)))){
	             		  flag = true;
	             		  sf.append(table+" Data Diff :"+getNullVal(rs1.getString(colName))+" :::::: "+getNullVal(rs2.getString(colName))+endLine);
	             		  break;
	             	   }
	             	  
	                    //String colType = rsmd.getColumnTypeName(i);
	            }
	            
	            if(flag){
	            	break;
	            }
	            
			}
	        
	        if(flag){
	        	
	        	sf.append("Table:::"+table+" not equal."+endLine);
	        	
	        }else{
	        	
	        	sf.append("Table:::"+table+" equal."+endLine);
	        	
	        }
		}catch(Exception e){
			print(e.getMessage(),"Error_"+Thread.currentThread().getName());
			e.printStackTrace();
		}
		
		return sf;
	}
	
	
	public void print(String data, String file){
		
	      try{    
	           FileWriter fw=new FileWriter(file+".txt");   
	           fw.write(data.toString());
	           fw.close();    
	          }catch(Exception e){
	        	  print(e.getMessage(),"error2");
	        	  System.out.println(e);
	          }
		
	}
	
	private String getVal(String arg) {
		
		return arg != null ? arg : "";
	}
	
	private String getNullVal(String arg){
		String val = arg;
		if(arg == null){
			val = " [null] ";
		}
		
		if(arg != null && "".equalsIgnoreCase(arg.trim())){
			val = " [null] ";
		}
		
		
		return val;
	
	}
}

package com.dct.db.db;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

public class CompareData {

    ResultSet resultSet1;

    ResultSet resultSet2;

    ResultSetMetaData resultSetMetaData;

    int size;

    public CompareData(ResultSet resultSet1,ResultSet resultSet2,ResultSetMetaData resultSetMetaData){

        this.resultSet1 = resultSet1;
        this.resultSet2 = resultSet2;
        this.resultSetMetaData = resultSetMetaData;
    }

    public ResultSet getResultSet1() {
        return resultSet1;
    }

    public void setResultSet1(ResultSet resultSet1) {
        this.resultSet1 = resultSet1;
    }

    public ResultSet getResultSet2() {
        return resultSet2;
    }

    public void setResultSet2(ResultSet resultSet2) {
        this.resultSet2 = resultSet2;
    }

    public ResultSetMetaData getResultSetMetaData() {
        return resultSetMetaData;
    }

    public void setResultSetMetaData(ResultSetMetaData resultSetMetaData) {
        this.resultSetMetaData = resultSetMetaData;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
}

package com.dct.controller;

import com.dct.db.db.ConnectionUtil;
import com.dct.db.entity.DataSource;
import com.dct.db.entity.Task;
import com.dct.db.so.ResultData;
import com.dct.service.DctOperationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Connection;
import java.util.List;

@RestController
@RequestMapping("dct")
public class DCTOperationalController {

    @Autowired
    private DctOperationService dctOperationService;

    @RequestMapping( value = "/testConnection",method = RequestMethod.POST)
    public ResultData testConnection(@RequestBody DataSource dataSource){

        Connection connection = ConnectionUtil.getConnection(dataSource);

        ResultData result = new ResultData();

        result.setStatus(connection != null ? "success" : "failure");
        return result;
    }

    @RequestMapping( value = "/save",method = RequestMethod.POST)
    public DataSource save(@RequestBody DataSource dataSource){
        return dctOperationService.save(dataSource);
    }

    @RequestMapping( value = "/getDataSource",method = RequestMethod.GET)
    public List<DataSource> getDataSource(){
        return dctOperationService.getDataSource();
    }

    @RequestMapping( value = "/getTasks",method = RequestMethod.GET)
    public List<Task> getTasks(){
        return dctOperationService.getTasks();
    }

    @RequestMapping( value = "/saveTask",method = RequestMethod.POST)
    public Task save(@RequestBody Task task){
        return dctOperationService.save(task);
    }

    @RequestMapping( value = "/getDataSources",method = RequestMethod.GET)
    public List<String> getDataSources(){
        return dctOperationService.getDataSources();
    }
    @RequestMapping( value = "/findDataSource",method = RequestMethod.GET)
    public DataSource getDataSource(@RequestParam("dataSourceName") String dataSourceName){
        return dctOperationService.getDataSourceByName(dataSourceName);
    }

    @RequestMapping( value = "/triggerTask",method = RequestMethod.POST)
    public Task triggerTask(@RequestBody Task task){
        return dctOperationService.triggerTask(task);
    }

}
